"""Read-only Twitch IRC over TLS WebSocket. Never sends PRIVMSG or uses a password."""
import asyncio
from contextlib import suppress
from dataclasses import dataclass
import os
import secrets
import time
from urllib.parse import urlsplit
import aiohttp


def unescape_tag(text):
    mapping = {'s': ' ', ':': ';', '\\': '\\', 'r': '\r', 'n': '\n'}
    out = []
    escaped = False
    for c in text:
        if escaped:
            out.append(mapping.get(c, c)); escaped = False
        elif c == '\\':
            escaped = True
        else:
            out.append(c)
    return ''.join(out)


@dataclass
class Message:
    tags: dict
    prefix: str
    command: str
    params: list
    body: str


def parse_line(line):
    tags = {}
    prefix = ''
    rest = line.strip('\r\n')
    if not rest:
        return None
    if rest.startswith('@'):
        raw, sep, rest = rest[1:].partition(' ')
        if not sep:
            return None
        for item in raw.split(';'):
            name, _, value = item.partition('=')
            tags[name] = unescape_tag(value)
    if rest.startswith(':'):
        prefix, sep, rest = rest[1:].partition(' ')
        if not sep:
            return None
    head, sep, body = rest.partition(' :')
    parts = head.split()
    if not parts:
        return None
    return Message(tags, prefix, parts[0].upper(), parts[1:], body if sep else '')


class TwitchChat:
    def __init__(self, on_message, on_status, url='wss://irc-ws.chat.twitch.tv:443'):
        self.on_message = on_message
        self.on_status = on_status
        self.url = url
        self.running = False
        self.task = None
        self.session = None
        self.ws = None
        self.channel = ''
        self.last_pong = 0

    def start(self, channel):
        if self.running:
            return
        self.channel = channel
        self.running = True
        self.task = asyncio.create_task(self.run())

    async def stop(self):
        self.running = False
        if self.task:
            self.task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await self.task
        self.task = None
        self.on_status('offline', 'Чат Twitch отключён')

    async def ping_loop(self, ws):
        while True:
            await asyncio.sleep(10)
            if time.monotonic() - self.last_pong > 28:
                await ws.close()
                return
            await ws.send_str('PING :croupyx-keepalive\r\n')

    async def run(self):
        failures = 0
        try:
            self.session = aiohttp.ClientSession(trust_env=True, timeout=aiohttp.ClientTimeout(total=20))
            while self.running:
                self.on_status('connecting' if not failures else 'reconnecting', f'Подключаем чат #{self.channel}…')
                try:
                    proxy = None
                    if not self.url.startswith(('ws://127.0.0.1', 'ws://localhost')):
                        proxy = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
                    async with self.session.ws_connect(self.url, proxy=proxy,
                            max_msg_size=65536, timeout=aiohttp.ClientWSTimeout(ws_close=3)) as ws:
                        self.ws = ws
                        nick = 'justinfan' + str(secrets.randbelow(90000000) + 10000000)
                        await ws.send_str('CAP REQ :twitch.tv/tags twitch.tv/commands twitch.tv/membership\r\n')
                        await ws.send_str('PASS SCHMOOPIIE\r\n')  # Public anonymous read-only handshake, not a secret.
                        await ws.send_str(f'NICK {nick}\r\n')
                        await ws.send_str(f'JOIN #{self.channel}\r\n')
                        joined = False
                        join_started = time.monotonic()
                        self.last_pong = time.monotonic()
                        pinger = asyncio.create_task(self.ping_loop(ws))
                        try:
                            while self.running:
                                raw = await asyncio.wait_for(ws.receive(), 35 if joined else 15)
                                if not joined and time.monotonic() - join_started > 20:
                                    raise ConnectionError('Twitch не подтвердил канал')
                                if raw.type != aiohttp.WSMsgType.TEXT:
                                    break
                                for line in raw.data.split('\r\n'):
                                    message = parse_line(line)
                                    if not message:
                                        continue
                                    if message.command == 'PING':
                                        await ws.send_str('PONG :' + (message.body or 'tmi.twitch.tv') + '\r\n')
                                    elif message.command == 'PONG':
                                        self.last_pong = time.monotonic()
                                    elif message.command == 'RECONNECT':
                                        raise ConnectionError('Twitch запросил переподключение')
                                    elif message.command == 'NOTICE':
                                        if 'authentication' in message.body.lower() or 'improperly formatted' in message.body.lower():
                                            raise ConnectionError('Twitch отклонил анонимное подключение')
                                    elif message.command == 'ROOMSTATE' and f'#{self.channel}' in message.params:
                                        if not message.tags.get('room-id', '').isdigit() or int(message.tags['room-id']) <= 0:
                                            raise ConnectionError('Не удалось подтвердить канал Twitch')
                                        if not joined:
                                            joined = True
                                            failures = 0
                                            self.on_status('online', f'Чат #{self.channel} подключён • чтение без пароля')
                                    elif message.command == 'PRIVMSG' and message.params and message.params[0] == f'#{self.channel}':
                                        if joined:
                                            self.on_message(message)
                        finally:
                            pinger.cancel()
                            with suppress(asyncio.CancelledError, Exception):
                                await pinger
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    note = 'Twitch недоступен (' + type(exc).__name__ + '). Повторяем подключение…'
                else:
                    note = 'Соединение с чатом прервано. Переподключаемся…'
                finally:
                    self.ws = None
                if self.running:
                    self.on_status('reconnecting', note)
                    failures += 1
                    await asyncio.sleep(min(30, 2 ** min(failures, 5)))
        finally:
            if self.session:
                await self.session.close()
                self.session = None


class Avatars:
    """Best-effort public avatar lookup; scoring never waits for this service."""
    def __init__(self):
        self.cache = {}
        self.tasks = set()
        self.session = None
        self.queue = asyncio.Queue(maxsize=100)
        self.pending = set()

    def get(self, login):
        return self.cache.get(login, '')

    def request(self, login):
        if login in self.cache or login in self.pending or self.queue.full():
            return
        self.pending.add(login)
        self.queue.put_nowait(login)

    async def run(self):
        async with aiohttp.ClientSession(trust_env=True, timeout=aiohttp.ClientTimeout(total=8)) as session:
            self.session = session
            while True:
                login = await self.queue.get()
                url = ''
                try:
                    async with session.get('https://decapi.me/twitch/avatar/' + login) as response:
                        value = (await response.text())[:2048].strip()
                        host = urlsplit(value).hostname
                        if response.status == 200 and value.startswith('https://') and host == 'static-cdn.jtvnw.net':
                            url = value
                except (aiohttp.ClientError, asyncio.TimeoutError, ValueError):
                    pass
                self.cache[login] = url
                self.pending.discard(login)
                self.queue.task_done()
                await asyncio.sleep(1)  # Public service: at most one lookup per second.
