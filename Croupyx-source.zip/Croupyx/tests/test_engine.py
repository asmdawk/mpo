from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from engine import Game,validate_settings,validate_word

class Clock:
    def __init__(self):self.now=100.0
    def __call__(self):return self.now
    def step(self,n):self.now+=n

def game(word='котлета'):
    clock=Clock();g=Game(['котлета','ракета'],clock=clock,wall_clock=clock);g.start(word)
    return g,clock

def guess(g,c,text,uid='1'):
    c.step(.6);return g.guess(uid,'Игрок '+uid,'player'+uid,text)

def test_substring_and_repeated_positions():
    g,c=game();hit=guess(g,c,'кот');assert hit['points']==3
    assert g.snapshot()['mask']==['К','О','Т',None,None,None,None]
    assert guess(g,c,'т')['points']==1
    assert g.snapshot()['mask']==['К','О','Т',None,None,'Т',None]

def test_single_letter_opens_all_occurrences():
    g,c=game();assert guess(g,c,'т')['points']==2

def test_substring_opens_every_occurrence_including_overlaps():
    g,c=game('банан');assert guess(g,c,'ан')['points']==4
    g,c=game('аааа');assert guess(g,c,'аа')['points']==4

def test_new_positions_only():
    g,c=game();guess(g,c,'к');assert guess(g,c,'кот','2')['points']==2
    assert guess(g,c,'кот') is None
    assert sum(p.score for p in g.players.values())==3

def test_wrong_and_noncontiguous_ignored():
    g,c=game();assert guess(g,c,'кол') is None
    assert guess(g,c,'ф') is None
    assert not g.players and not g.recent

def test_whole_word_wins_even_with_lower_score_and_no_cooldown():
    g,c=game();guess(g,c,'котлет','1');assert g.players['1'].score==6
    g.guess('2','B','player2','ф');g.guess('2','B','player2','котлета')
    assert g.phase=='finished' and g.winner=='2' and g.result_type=='word'
    assert g.players['2'].score==1

def test_all_letters_opened_does_not_win_without_full_word():
    g,c=game();guess(g,c,'кот');guess(g,c,'лета','2');assert len(g.opened)==len(g.word)
    assert g.phase=='playing'
    guess(g,c,'котлета','3');assert g.winner=='3' and g.players['3'].score==0

def test_timeout_score_and_earliest_tie():
    g,c=game();guess(g,c,'ко','2');guess(g,c,'ле','1');c.step(61);g.tick()
    assert g.winner=='2' and g.result_type=='score'

def test_timeout_no_guess_no_winner():
    g,c=game();c.step(60);g.tick();assert g.phase=='finished' and g.winner is None
    assert g.snapshot()['answer']=='КОТЛЕТА'

def test_exact_deadline_late_full_word_rejected():
    g,c=game();guess(g,c,'ко');c.now=160
    assert g.guess('2','B','b','котлета') is None and g.winner=='1'

def test_pause_freezes_time_and_rejects_messages():
    g,c=game();c.step(10);g.pause();c.step(300);g.tick()
    assert g.phase=='paused' and g.snapshot()['remaining']==50
    assert g.guess('1','A','a','котлета') is None
    g.resume();assert g.deadline==c.now+50

def test_buffered_old_messages_cannot_score_after_start_or_resume():
    g,c=game();assert g.guess('1','A','a','котлета',sent_at=99) is None
    g.pause();c.step(20);g.resume()
    assert g.guess('1','A','a','котлета',sent_at=119) is None
    assert g.guess('1','A','a','котлета',sent_at=120)

def test_answer_never_leaks_public_during_round_or_pause():
    g,c=game();assert g.snapshot()['answer'] is None
    assert g.snapshot(admin=True)['answer']=='КОТЛЕТА'
    g.pause();assert g.snapshot()['answer'] is None

@pytest.mark.parametrize('text',['<script>','ко т','кот!','123','', 'к\nо','ко-т'])
def test_non_letter_messages_ignored(text):
    g,c=game();assert guess(g,c,text) is None

def test_case_whitespace_and_yo():
    g,c=game('ёжик');assert guess(g,c,'  ЕЖ  ')['points']==2
    assert guess(g,c,'ЁЖИК')['complete']

def test_cooldown_does_not_delay_full_word():
    g,c=game();assert g.guess('1','A','a','к')
    assert g.guess('1','A','a','о') is None
    assert g.guess('1','A','a','котлета')

def test_no_join_or_twelve_player_limit():
    # Every correct new-position opener participates, including player 13.
    word='абвгдежзийклмнопрсту';g,c=game(word)
    for i,ch in enumerate(word):guess(g,c,ch,str(i))
    assert len(g.players)==len(word) and len(g.players)>12

def test_reset_and_history():
    g,c=game();guess(g,c,'котлета');g.reset()
    assert g.phase=='idle' and not g.players and len(g.history)==1

def test_invalid_word_does_not_erase_finished_round():
    g,c=game();guess(g,c,'котлета');old=g.round_id
    with pytest.raises(ValueError):g.start('bad word')
    assert g.phase=='finished' and g.round_id==old

def test_cannot_start_over_running_game():
    g,c=game()
    with pytest.raises(ValueError):g.start()

def test_settings_and_word_validation():
    for bad in [dict(channel='https://twitch.tv/no'),dict(round_seconds=1),dict(cooldown_ms=-1),dict(difficulty='unknown')]:
        with pytest.raises(ValueError):validate_settings(bad)
    for word in ['ab','a'*21,'a b','123']:
        with pytest.raises(ValueError):validate_word(word)

def test_auto_next_countdown():
    g,c=game();g.settings['auto_next']=True;guess(g,c,'котлета')
    assert g.snapshot()['next_in']==8

def test_random_dictionary_has_requested_length():
    g=Game(['котлета','компьютер','энциклопедия']);g.settings['difficulty']='long'
    assert g.choose_word()=='энциклопедия'
