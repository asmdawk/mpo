from pathlib import Path
import sys,os,tempfile,asyncio
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
os.environ['CROUPYX_DATA']=tempfile.mkdtemp(prefix='croupyx-test-')
from twitch import parse_line,unescape_tag,TwitchChat
from app import Service
from aiohttp import web

def message(text,mid='one',user='12',login='tester',sent=None):
    tags=f'@id={mid};user-id={user};display-name=Tester'
    if sent is not None:tags+=f';tmi-sent-ts={sent}'
    return parse_line(tags+f' :{login}!{login}@{login}.tmi.twitch.tv PRIVMSG #croupyx :{text}')

def test_parse_tags_and_message():
    m=message('КОТ');assert m.command=='PRIVMSG' and m.body=='КОТ'
    assert m.tags['user-id']=='12' and m.params==['#croupyx']

def test_irc_tag_escapes_and_ping():
    assert unescape_tag(r'Hello\sworld\:x\\y')=='Hello world;x\\y'
    m=parse_line('PING :tmi.twitch.tv');assert m.command=='PING' and m.body=='tmi.twitch.tv'
    assert parse_line('') is None and parse_line('@oops') is None

def test_message_id_deduplication():
    s=Service();s.game.start('котлета');s.handle_message(message('т'))
    s.handle_message(message('т'));assert s.game.players['twitch:12'].score==2
    assert s.messages_received==1 and s.hits_received==1

def test_wrong_does_not_appear_on_board():
    s=Service();s.game.start('котлета');s.handle_message(message('абракадабра'))
    assert not s.game.players and not s.game.recent

def test_disconnect_pauses_and_reconnect_requires_manual_resume():
    s=Service();s.game.start('котлета');s.on_status('reconnecting','test');s.on_status('online','test')
    s.handle_message(message('котлета'));assert s.game.phase=='paused' and not s.game.winner

def test_demo_ignores_real_chat():
    s=Service();s.game.start('котлета',demo=True);s.handle_message(message('котлета'))
    assert s.game.phase=='playing' and not s.game.players

def test_old_timestamp_rejected():
    s=Service();s.game.start('котлета');s.handle_message(message('котлета',sent=1))
    assert s.game.phase=='playing' and not s.game.players

def test_websocket_protocol_against_local_twitch_server():
    async def run():
        events=[];statuses=[];writes=[]
        async def fake(request):
            ws=web.WebSocketResponse();await ws.prepare(request)
            while True:
                msg=await asyncio.wait_for(ws.receive(),5)
                writes.append(msg.data)
                if 'JOIN #croupyx' in msg.data:break
            await ws.send_str(':tmi.twitch.tv 366 justinfan #croupyx :End of /NAMES list\r\n@room-id=123 :tmi.twitch.tv ROOMSTATE #croupyx\r\nPING :test-server\r\n')
            await ws.send_str('@id=x;user-id=12;display-name=Tester :tester!tester@tmi PRIVMSG #croupyx :кот\r\n')
            pong=await asyncio.wait_for(ws.receive(),5);writes.append(pong.data)
            await asyncio.sleep(.2);await ws.close();return ws
        app=web.Application();app.router.add_get('/',fake);runner=web.AppRunner(app);await runner.setup()
        site=web.TCPSite(runner,'127.0.0.1',0);await site.start();port=site._server.sockets[0].getsockname()[1]
        chat=TwitchChat(events.append,lambda state,note:statuses.append(state),url=f'ws://127.0.0.1:{port}/')
        try:
            chat.start('croupyx')
            for _ in range(100):
                if events and any('PONG :test-server' in v for v in writes):break
                await asyncio.sleep(.02)
            assert 'online' in statuses and events[0].body=='кот'
            assert any('PONG :test-server' in v for v in writes)
            assert not any(v.startswith('PRIVMSG') for v in writes)
            assert all(v.count('\r\n') <= 1 for v in writes)
        finally:
            await chat.stop();await runner.cleanup()
    asyncio.run(run())
