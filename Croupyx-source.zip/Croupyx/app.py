"""Croupyx desktop service: private control panel + read-only OBS overlay."""
import asyncio
from collections import OrderedDict, deque
from contextlib import suppress
import json
import logging
import os
from pathlib import Path
import re
import secrets
import sys
import time
import webbrowser
from aiohttp import web
from engine import Game, validate_settings
from twitch import TwitchChat, Avatars

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('CROUPYX_DATA', str(Path(os.environ.get('LOCALAPPDATA', str(ROOT))) / 'Croupyx' / 'data')))
DATA.mkdir(parents=True, exist_ok=True)
PORT = int(os.environ.get('CROUPYX_PORT', '17895'))
BASE = f'http://127.0.0.1:{PORT}'
TOKEN_PATH = DATA / 'admin.key'
if not TOKEN_PATH.exists():
    TOKEN_PATH.write_text(secrets.token_urlsafe(32), encoding='ascii')
TOKEN = TOKEN_PATH.read_text(encoding='ascii').strip()
logging.basicConfig(filename=DATA / 'croupyx.log', level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')


class Service:
    def __init__(self):
        self.settings_path = DATA / 'settings.json'
        try:
            settings = validate_settings(json.loads(self.settings_path.read_text('utf-8')))
        except (OSError, ValueError, TypeError):
            settings = None
        words = json.loads((ROOT / 'words.json').read_text('utf-8'))
        self.game = Game(words, settings)
        try:
            history = json.loads((DATA / 'history.json').read_text('utf-8'))
            if isinstance(history, list):
                self.game.history = history[:30]
        except (OSError, ValueError, TypeError):
            pass
        self.connection = 'offline'
        self.connection_note = 'Введите канал и подключите чат — пароль не нужен'
        self.chat = TwitchChat(self.handle_message, self.on_status)
        self.avatars = Avatars()
        self.peers = set()
        self.seen = OrderedDict()
        self.events = deque(maxlen=60)
        self.messages_received = 0
        self.hits_received = 0
        self.last_message = None
        self.demo_index = 0
        self.demo_next = 0
        self.last_history = ''
        self.stopping = asyncio.Event()

    def log(self, text):
        self.events.appendleft(dict(time=time.strftime('%H:%M:%S'), text=str(text)[:200]))

    def on_status(self, status, note):
        previous = self.connection
        self.connection = status
        self.connection_note = note
        if status != previous:
            self.log(note)
        if status != 'online' and not self.game.demo:
            self.game.pause('Чат Twitch отключён. После восстановления нажмите «Продолжить».')

    def handle_message(self, message):
        self.last_message = time.time()
        mid = message.tags.get('id')
        if mid:
            if mid in self.seen:
                return
            self.seen[mid] = True
            if len(self.seen) > 20000:
                self.seen.popitem(last=False)
        self.messages_received += 1
        if self.game.demo:
            return
        login = message.prefix.partition('!')[0].lower()
        if not re.fullmatch(r'[a-z0-9_]{1,25}', login):
            return
        user_id = message.tags.get('user-id')
        uid = 'twitch:' + user_id if user_id and user_id.isdigit() else 'login:' + login
        name = message.tags.get('display-name') or login
        sent_at = None
        try:
            if message.tags.get('tmi-sent-ts'):
                sent_at = int(message.tags['tmi-sent-ts']) / 1000
        except (ValueError, TypeError):
            return
        hit = self.game.guess(uid, name, login, message.body,
                              self.avatars.get(login), sent_at=sent_at)
        if hit:
            self.hits_received += 1
            self.log(f'{name}: {hit["guess"]} +{hit["points"]}')
            self.avatars.request(login)

    async def command(self, data):
        action = data.get('action')
        g = self.game
        if action == 'settings':
            if g.phase not in ('idle', 'finished') or self.chat.running:
                raise ValueError('Меняйте настройки между раундами, предварительно отключив чат')
            settings = validate_settings(data.get('settings', {}))
            self.settings_path.write_text(json.dumps(settings, ensure_ascii=False, indent=2), 'utf-8')
            g.settings = settings
            self.log('Настройки сохранены')
        elif action == 'connect':
            if g.demo and g.phase not in ('idle', 'finished'):
                raise ValueError('Сначала завершите демо')
            self.chat.start(g.settings['channel'])
            self.connection = 'connecting'
        elif action == 'disconnect':
            await self.chat.stop()
        elif action in ('start', 'demo'):
            demo = action == 'demo'
            if demo and self.chat.running:
                raise ValueError('Перед демо отключите чат Twitch')
            if not demo and self.connection != 'online':
                raise ValueError('Сначала подключите чат Twitch')
            g.start(data.get('word') or ('котлета' if demo else None), demo=demo)
            self.demo_index = 0
            self.demo_next = time.monotonic() + 1.5
            self.log('Новый раунд • ' + ('ДЕМО' if demo else 'TWITCH'))
        elif action == 'pause':
            g.pause()
        elif action == 'resume':
            if not g.demo and self.connection != 'online':
                raise ValueError('Сначала восстановите подключение к Twitch')
            g.resume()
        elif action == 'finish':
            g.end()
        elif action == 'reset':
            g.reset()
            self.log('Раунд сброшен')
        elif action == 'shutdown':
            self.stopping.set()
        else:
            raise ValueError('Неизвестная команда')

    def state(self, admin=False):
        state = self.game.snapshot(admin=admin)
        state['settings'] = self.game.settings
        state['connection'] = self.connection
        if admin:
            state |= dict(connection_note=self.connection_note, events=list(self.events),
                          messages_received=self.messages_received, hits_received=self.hits_received,
                          last_message=self.last_message, display_url=BASE + '/board')
        return state

    def demo_tick(self):
        g = self.game
        now = time.monotonic()
        if not g.demo or g.phase != 'playing' or now < self.demo_next:
            return
        names = ['PixelFox', 'neon_kot', 'LunaGG', 'VikaWin', 'DarkPanda', 'AlexQuest']
        steps = [g.word[:1], g.word[1:3], 'zzzzzzzzzzzzzzzzzzzzz', g.word[3:5], g.word[5:], g.word]
        i = min(self.demo_index, len(steps) - 1)
        g.guess(f'demo-{i}', names[i], names[i].lower(), steps[i], f'/static/avatars/{i}.svg')
        self.demo_index += 1
        self.demo_next = now + 1.7

    async def loop(self):
        while not self.stopping.is_set():
            self.game.tick()
            self.demo_tick()
            g = self.game
            if g.phase == 'finished' and g.next_deadline and time.monotonic() >= g.next_deadline:
                if g.demo or self.connection == 'online':
                    demo = g.demo
                    g.start(demo=demo)
                    self.demo_index = 0
                    self.demo_next = time.monotonic() + 1.5
            # Resolve only active scoreboard avatars. Never block a chat event on HTTP.
            if not g.demo:
                for player in g.ranking()[:8]:
                    self.avatars.request(player.login)
                    player.avatar = self.avatars.get(player.login)
                for hit in g.recent:
                    hit['avatar'] = self.avatars.get(hit['login'])
            history = json.dumps(g.history, ensure_ascii=False)
            if history != self.last_history:
                (DATA / 'history.json').write_text(history, 'utf-8')
                self.last_history = history
            # Share one public and one private serialization per frame.
            snapshots = {False: json.dumps(self.state(False), ensure_ascii=False)}
            if any(admin for _, admin in self.peers):
                snapshots[True] = json.dumps(self.state(True), ensure_ascii=False)
            async def push(ws, admin):
                try:
                    await asyncio.wait_for(ws.send_str(snapshots[admin]), .12)
                except Exception:
                    self.peers.discard((ws, admin))
                    asyncio.create_task(ws.close())
            if self.peers:
                await asyncio.gather(*(push(ws, admin) for ws, admin in list(self.peers)))
            await asyncio.sleep(.06)


service = Service()


@web.middleware
async def guard(request, handler):
    if request.host != f'127.0.0.1:{PORT}':
        raise web.HTTPForbidden(text='Недопустимый адрес')
    if request.headers.get('Origin') not in (None, BASE):
        raise web.HTTPForbidden(text='Недопустимый источник')
    response = await handler(request)
    response.headers.update({
        'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store',
        'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; connect-src 'self' ws://127.0.0.1:*; frame-ancestors 'self'"
    })
    return response


async def page(request):
    return web.FileResponse(ROOT / 'static' / ('board.html' if request.path == '/board' else 'admin.html'))


async def api(request):
    if not secrets.compare_digest(request.headers.get('X-Croupyx-Key', ''), TOKEN):
        raise web.HTTPForbidden(text='Откройте панель через Croupyx.exe')
    try:
        data = await request.json()
        if not isinstance(data, dict):
            raise ValueError('Ожидается объект команды')
        await service.command(data)
        return web.json_response({'ok': True})
    except (ValueError, TypeError, KeyError) as exc:
        return web.json_response({'error': str(exc)}, status=400)


async def socket(request):
    ws = web.WebSocketResponse(heartbeat=10, max_msg_size=4096)
    await ws.prepare(request)
    admin = False
    try:
        hello = await asyncio.wait_for(ws.receive_json(), 5)
        if not isinstance(hello, dict):
            await ws.close()
            return ws
        admin = secrets.compare_digest(str(hello.get('key', '')), TOKEN)
        service.peers.add((ws, admin))
        await ws.send_json(service.state(admin))
        async for _ in ws:
            pass
    except (asyncio.TimeoutError, ValueError, TypeError):
        pass
    finally:
        service.peers.discard((ws, admin))
    return ws


async def health(request):
    return web.json_response({'app': 'Croupyx', 'version': '2.0.0'})


async def main():
    app = web.Application(middlewares=[guard], client_max_size=8192)
    app.router.add_get('/', page)
    app.router.add_get('/board', page)
    app.router.add_get('/health', health)
    app.router.add_get('/ws', socket)
    app.router.add_post('/api', api)
    app.router.add_static('/static', ROOT / 'static', show_index=False)
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    try:
        await web.TCPSite(runner, '127.0.0.1', PORT).start()
    except OSError:
        import urllib.request
        try:
            with urllib.request.urlopen(BASE + '/health', timeout=2) as r:
                if json.load(r).get('app') != 'Croupyx':
                    raise RuntimeError('Порт занят')
            if not os.environ.get('CROUPYX_NO_BROWSER'):
                webbrowser.open(BASE + '/#' + TOKEN)
        except Exception:
            if sys.platform == 'win32':
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, 'Порт 17895 занят. Закройте другую программу и попробуйте снова.', 'Croupyx', 16)
        await runner.cleanup()
        return
    if not os.environ.get('CROUPYX_NO_BROWSER'):
        webbrowser.open(BASE + '/#' + TOKEN)
    task = asyncio.create_task(service.loop())
    avatars = asyncio.create_task(service.avatars.run())
    try:
        await service.stopping.wait()
    finally:
        task.cancel(); avatars.cancel()
        for pending in [task, avatars]:
            with suppress(asyncio.CancelledError):
                await pending
        await service.chat.stop()
        await runner.cleanup()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    except Exception:
        logging.exception('Fatal startup error')
        if sys.platform == 'win32':
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, 'Не удалось открыть Croupyx. Журнал: ' + str(DATA / 'croupyx.log'), 'Croupyx', 16)
