"""Croupyx word game. Pure rules; Twitch messages never control the admin UI."""
from dataclasses import dataclass, asdict
from collections import OrderedDict
import random
import re
import secrets
import time


DEFAULTS = dict(channel='croupyx', round_seconds=60, difficulty='mixed',
                cooldown_ms=500, sound=True, auto_next=False, next_delay=8)
LETTERS = re.compile(r'^[a-zа-яё]+$', re.I)


def normalize(value):
    return str(value).strip().casefold().replace('ё', 'е')


def validate_word(word):
    value = normalize(word)
    if not 3 <= len(value) <= 20 or not LETTERS.fullmatch(value):
        raise ValueError('Слово: от 3 до 20 русских или английских букв, без пробелов')
    return value


def validate_settings(data):
    s = DEFAULTS | data
    channel = str(s['channel']).strip().lstrip('@').lower()
    if not re.fullmatch(r'[a-z0-9_]{1,25}', channel):
        raise ValueError('Нужен логин Twitch без ссылки: например croupyx')
    s['channel'] = channel
    for key, low, high in [('round_seconds', 10, 600), ('cooldown_ms', 0, 3000), ('next_delay', 5, 30)]:
        if type(s[key]) is not int or not low <= s[key] <= high:
            raise ValueError(f'{key}: допустимо от {low} до {high}')
    if s['difficulty'] not in ('short', 'medium', 'long', 'mixed'):
        raise ValueError('Выберите длину слов')
    s['sound'] = bool(s['sound'])
    s['auto_next'] = bool(s['auto_next'])
    return {key: s[key] for key in DEFAULTS}


@dataclass
class Player:
    id: str
    name: str
    login: str
    score: int = 0
    avatar: str = ''
    last_score_at: float = 0


class Game:
    def __init__(self, words, settings=None, clock=time.monotonic, wall_clock=time.time):
        self.settings = validate_settings(settings or {})
        self.words = list(dict.fromkeys(validate_word(word) for word in words))
        if not self.words:
            raise ValueError('Словарь пуст')
        self.clock = clock
        self.wall_clock = wall_clock
        self.round_id = 0
        self.round_number = 0
        self.history = []
        self.used_words = []
        self.reset()

    def reset(self):
        self.round_id += 1
        self.phase = 'idle'
        self.word = ''
        self.opened = set()
        self.players = {}
        self.recent = []
        self.deadline = 0
        self.remaining = 0
        self.pause_reason = ''
        self.winner = None
        self.result_reason = ''
        self.result_type = ''
        self.demo = False
        self.accept_after = 0
        self.attempts = OrderedDict()
        self.next_deadline = 0

    def choose_word(self):
        bounds = {'short': (4, 6), 'medium': (7, 9), 'long': (10, 14), 'mixed': (4, 12)}
        low, high = bounds[self.settings['difficulty']]
        pool = [w for w in self.words if low <= len(w) <= high and w not in self.used_words[-15:]]
        if not pool:
            pool = [w for w in self.words if low <= len(w) <= high] or self.words
        return secrets.choice(pool)

    def start(self, word=None, demo=False):
        if self.phase not in ('idle', 'finished'):
            raise ValueError('Завершите или сбросьте текущий раунд')
        # Validate before mutation: a malformed custom word cannot erase a round.
        chosen = validate_word(word) if word else self.choose_word()
        self.reset()
        self.word = chosen
        self.used_words.append(chosen)
        self.used_words = self.used_words[-30:]
        self.demo = demo
        self.phase = 'playing'
        self.round_number += 1
        self.deadline = self.clock() + self.settings['round_seconds']
        self.accept_after = self.wall_clock()

    def ranking(self):
        # dict insertion order resolves a complete timestamp/score tie.
        return sorted(self.players.values(), key=lambda p: (-p.score, p.last_score_at))

    def guess(self, uid, name, login, text, avatar='', sent_at=None):
        self.tick()
        if self.phase != 'playing' or not uid:
            return None
        if sent_at is not None and sent_at < self.accept_after:
            return None  # Never count a buffered answer from a previous round/pause.
        guess = normalize(text)
        if not LETTERS.fullmatch(guess) or len(guess) > len(self.word):
            return None
        uid = str(uid)
        complete = guess == self.word
        now = self.clock()
        last_attempt = self.attempts.get(uid)
        # A full-word answer always gets checked immediately, including after a guess.
        if not complete and last_attempt is not None and now - last_attempt < self.settings['cooldown_ms'] / 1000:
            return None
        self.attempts[uid] = now
        self.attempts.move_to_end(uid)
        if len(self.attempts) > 20000:
            self.attempts.popitem(last=False)
        positions = set()
        offset = self.word.find(guess)
        while offset >= 0:
            positions.update(range(offset, offset + len(guess)))
            offset = self.word.find(guess, offset + 1)
        new = positions - self.opened
        if not new and not complete:
            return None
        player = self.players.get(uid)
        if not player:
            player = Player(uid, str(name)[:50] or str(login)[:25], str(login)[:25], avatar=avatar)
            self.players[uid] = player
        player.score += len(new)
        if new:
            player.last_score_at = now
        self.opened.update(new)
        hit = dict(id=uid, name=player.name, login=player.login, avatar=player.avatar,
                   guess=guess.upper(), points=len(new), complete=complete,
                   sequence=len(self.recent) + 1, received_at=self.wall_clock())
        self.recent.insert(0, hit)
        self.recent = self.recent[:12]
        if complete:
            self.finish(player, 'Слово угадано целиком', 'word')
        return hit

    def finish(self, player=None, reason='', result_type='score'):
        if self.phase == 'finished':
            return
        self.phase = 'finished'
        self.remaining = 0
        self.winner = player.id if player else None
        self.result_reason = reason or 'Больше всех новых букв за раунд'
        self.result_type = result_type
        self.opened.update(range(len(self.word)))
        self.next_deadline = self.clock() + self.settings['next_delay'] if self.settings['auto_next'] else 0
        if player:
            self.history.insert(0, dict(name=player.name, login=player.login, score=player.score,
                                       answer=self.word.upper(), result_type=result_type, demo=self.demo,
                                       time=time.strftime('%d.%m %H:%M', time.localtime(self.wall_clock()))))
            self.history = self.history[:30]

    def end(self):
        if self.phase not in ('playing', 'paused'):
            raise ValueError('Сейчас нет активного раунда')
        ranks = self.ranking()
        self.finish(ranks[0] if ranks else None,
                    'Больше всех новых букв за раунд' if ranks else 'Никто не открыл буквы. Попробуем ещё?',
                    'score' if ranks else 'none')

    def pause(self, reason='Пауза ведущего'):
        self.tick()
        if self.phase == 'playing':
            self.remaining = max(0, self.deadline - self.clock())
            self.phase = 'paused'
            self.pause_reason = reason

    def resume(self):
        if self.phase == 'paused':
            self.phase = 'playing'
            self.deadline = self.clock() + self.remaining
            self.accept_after = self.wall_clock()
            self.pause_reason = ''

    def tick(self):
        if self.phase == 'playing' and self.clock() >= self.deadline:
            self.end()

    def snapshot(self, admin=False):
        ranks = self.ranking()
        winner = self.players.get(self.winner)
        remaining = self.remaining if self.phase == 'paused' else max(0, self.deadline - self.clock())
        return dict(phase=self.phase, round_id=self.round_id, round_number=self.round_number,
                    remaining=round(remaining, 2) if self.phase in ('playing', 'paused') else 0,
                    mask=[c.upper() if i in self.opened else None for i, c in enumerate(self.word)],
                    opened=len(self.opened), length=len(self.word), all_open=bool(self.word) and len(self.opened) == len(self.word),
                    answer=self.word.upper() if admin or self.phase == 'finished' else None,
                    players=[asdict(p) for p in ranks[:8]], player_count=len(self.players),
                    recent=self.recent[:5], winner=asdict(winner) if winner else None,
                    result_reason=self.result_reason, result_type=self.result_type,
                    pause_reason=self.pause_reason, demo=self.demo, history=self.history,
                    next_in=round(max(0, self.next_deadline - self.clock()), 2) if self.next_deadline else None)
