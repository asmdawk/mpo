"""Cross-build a self-contained Windows x64 EXE on Linux, using Zig + Python embed.

Prerequisites: ziglang Python package; Windows embed runtime with installed wheels
in ../win-runtime. Dependencies come from requirements-win.lock.
"""
from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
RUNTIME = Path(os.environ.get('CROUPYX_RUNTIME', WORK / 'croupyx-runtime'))
OUT = Path(os.environ.get('CROUPYX_OUTPUT', WORK.parent / 'output'))
OUT.mkdir(parents=True, exist_ok=True)
for name in ['app.py', 'engine.py', 'twitch.py', 'words.json', 'README.md']:
    shutil.copy2(ROOT / name, RUNTIME / name)
shutil.copytree(ROOT / 'static', RUNTIME / 'static', dirs_exist_ok=True)
(RUNTIME / 'third-party').mkdir(exist_ok=True)
shutil.copy2(ROOT / 'vendor/miniz/LICENSE', RUNTIME / 'third-party/miniz-LICENSE.txt')

payload = WORK / 'croupyx-payload.zip'
with zipfile.ZipFile(payload, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(RUNTIME.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.pyc'):
            z.write(p, p.relative_to(RUNTIME).as_posix())
build_id = hashlib.sha256(payload.read_bytes()).hexdigest()[:12]
rc = WORK / 'croupyx-resources.rc'
rc.write_text(f'''// Croupyx Windows resources
#pragma code_page(65001)
101 RCDATA "{payload.as_posix()}"
102 ICON "{(ROOT / 'icon.ico').as_posix()}"
1 24 "{(ROOT / 'app.manifest').as_posix()}"
1 VERSIONINFO
FILEVERSION 2,0,0,0
PRODUCTVERSION 2,0,0,0
FILEOS 0x40004
FILETYPE 1
BEGIN
  BLOCK "StringFileInfo"
  BEGIN
    BLOCK "040904B0"
    BEGIN
      VALUE "FileDescription", "Croupyx — Угадай слово / Twitch\\0"
      VALUE "FileVersion", "2.0.0\\0"
      VALUE "ProductName", "Croupyx\\0"
      VALUE "ProductVersion", "2.0.0\\0"
      VALUE "OriginalFilename", "Croupyx.exe\\0"
    END
  END
  BLOCK "VarFileInfo"
  BEGIN
    VALUE "Translation", 0x409, 1200
  END
END
''', encoding='utf-8')
env = os.environ | {'ZIG_GLOBAL_CACHE_DIR': str(WORK / 'zig-cache')}
zig = [sys.executable, '-m', 'ziglang']
subprocess.run(zig + ['rc', '/fo', str(WORK / 'croupyx-resources.res'), '--', str(rc)], env=env, check=True)
sources = [str(ROOT / 'launcher.c')] + [str(ROOT / 'vendor/miniz' / n) for n in ['miniz.c', 'miniz_zip.c', 'miniz_tinfl.c']]
subprocess.run(zig + ['cc', '-target', 'x86_64-windows-gnu', '-municode', '-Wl,--subsystem,windows', '-O2', '-s',
    '-DMINIZ_NO_ARCHIVE_WRITING_APIS', '-DMINIZ_NO_ZLIB_APIS', '-DMINIZ_NO_ZLIB_COMPATIBLE_NAMES',
    f'-DBUILD_ID=L"{build_id}"', *sources, str(WORK / 'croupyx-resources.res'), '-lshell32', '-lole32',
    '-o', str(OUT / 'Croupyx.exe')], env=env, check=True)
shutil.copy2(ROOT / 'README.md', OUT / 'README-Croupyx.md')
with zipfile.ZipFile(OUT / 'Croupyx-source.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:
            z.write(p, 'Croupyx/' + p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUT / 'Croupyx-Windows.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(OUT / 'Croupyx.exe', 'Croupyx.exe')
    z.write(ROOT / 'README.md', 'README.md')
    z.write(OUT / 'Croupyx-source.zip', 'Croupyx-source.zip')
for name in ['Croupyx.exe', 'Croupyx-Windows.zip', 'Croupyx-source.zip']:
    p = OUT / name
    print(f'{name}: {p.stat().st_size:,} bytes, SHA256 {hashlib.sha256(p.read_bytes()).hexdigest()}')
print('BUILD_ID', build_id)
