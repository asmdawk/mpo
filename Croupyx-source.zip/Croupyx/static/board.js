'use strict';
const $=id=>document.getElementById(id),preview=new URLSearchParams(location.search).has('preview');
if(preview)document.body.classList.add('preview-mode');
let previous=null,socket,audio=null,soundEnabled=false,cards=new Map(),toastDeadline=0;
function tone(freq=700,duration=.09){if(!soundEnabled||!audio||preview)return;const oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.connect(gain);gain.connect(audio.destination);oscillator.frequency.value=freq;gain.gain.setValueAtTime(.04,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);oscillator.start();oscillator.stop(audio.currentTime+duration);}
$('enable-sound').onclick=()=>{audio=audio||new AudioContext();audio.resume();soundEnabled=!soundEnabled;$('enable-sound').textContent=soundEnabled?'Звук включён':'Включить звук';tone();};
$('fullscreen').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen().catch(()=>{});};
function picture(element,p){const signature=p.avatar+'|'+p.name;if(element.dataset.signature===signature)return;element.dataset.signature=signature;element.replaceChildren();const fallback=()=>{element.replaceChildren(document.createTextNode(p.name.slice(0,2).toUpperCase()));};if(p.avatar&&(p.avatar.startsWith('https://')||p.avatar.startsWith('/static/'))){const img=document.createElement('img');img.alt='';img.referrerPolicy='no-referrer';img.src=p.avatar;img.onerror=fallback;element.append(img);}else fallback();}
function notice(message){$('notice').textContent=message;$('notice').classList.toggle('hidden',!message);}
function rankCard(p){const el=document.createElement('div');el.className='rank-row';const rank=document.createElement('span');rank.className='rank-number';const avatar=document.createElement('div');avatar.className='small-avatar';const name=document.createElement('span');name.className='rank-name';name.textContent=p.name;const score=document.createElement('strong');score.className='rank-score';el.append(rank,avatar,name,score);return el;}
function render(s){const fresh=!previous||previous.round_id!==s.round_id,phase=s.phase;
  $('channel').textContent=s.settings.channel;$('mode-label').textContent=s.demo?'ДЕМОНСТРАЦИЯ':s.connection==='online'?'ЧАТ ПОДКЛЮЧЁН':'TWITCH / ЧАТ';
  $('round-number').textContent=String(s.round_number||1).padStart(2,'0');$('opened').textContent=`${s.opened} / ${s.length||'?'}`;
  $('timer-label').textContent=phase==='paused'?'ПАУЗА':phase==='idle'?'ДО СТАРТА':'ОСТАЛОСЬ';const sec=Math.max(0,Math.ceil(s.remaining));$('timer').textContent=phase==='idle'?'—':String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');document.querySelector('.word-timer').classList.toggle('urgent',sec<=10&&phase==='playing');
  const mask=s.mask.length?s.mask:Array(7).fill(null),tiles=$('word-tiles');
  if(fresh||tiles.children.length!==mask.length){tiles.replaceChildren();for(let i=0;i<mask.length;i++){const el=document.createElement('span');el.className='letter-tile';el.textContent='_';tiles.append(el);}}
  for(let i=0;i<mask.length;i++){const el=tiles.children[i],value=mask[i]||'_';if(el.textContent!==value){el.textContent=value;el.classList.remove('fresh');if(mask[i]){void el.offsetWidth;el.classList.add('fresh');}}el.classList.toggle('revealed',!!mask[i]);}
  $('idle-instruction').classList.toggle('hidden',phase!=='idle');
  notice(phase==='paused'?s.pause_reason:s.all_open&&phase==='playing'?'Все буквы открыты — напиши слово целиком!':'');
  if(fresh){cards.clear();$('ranking').replaceChildren();$('hit-toast').classList.add('hidden');toastDeadline=0;}
  const ranking=$('ranking');if(!s.players.length){if(!ranking.querySelector('.empty-copy')){const p=document.createElement('p');p.className='empty-copy';p.textContent='Открой букву — попади на табло';ranking.replaceChildren(p);}}
  else{ranking.querySelector('.empty-copy')?.remove();s.players.forEach((p,i)=>{let card=cards.get(p.id);if(!card){card=rankCard(p);cards.set(p.id,card);}card.classList.toggle('first',i===0);card.querySelector('.rank-number').textContent=i+1;card.querySelector('.rank-score').textContent=p.score;picture(card.querySelector('.small-avatar'),p);if(ranking.children[i]!==card)ranking.insertBefore(card,ranking.children[i]||null);});for(const [id,card] of cards)if(!s.players.some(p=>p.id===id)){card.remove();cards.delete(id);}}
  $('player-count').textContent=s.player_count?`${s.player_count} игроков открыли буквы`:'Просто пиши ответ';
  const recentSignature=JSON.stringify(s.recent);if($('recent').dataset.signature!==recentSignature){$('recent').dataset.signature=recentSignature;const rows=s.recent.slice(0,3).map(hit=>{const row=document.createElement('div');row.className='recent-row';const avatar=document.createElement('div');avatar.className='small-avatar';picture(avatar,hit);const name=document.createElement('span');name.className='recent-name';name.textContent=hit.name;const arrow=document.createElement('span');arrow.className='recent-arrow';arrow.textContent='→';const guess=document.createElement('span');guess.className='recent-guess';guess.textContent=hit.guess;const points=document.createElement('span');points.className='recent-points';points.textContent='+'+hit.points;row.append(avatar,name,arrow,guess,points);return row;});if(!rows.length){const p=document.createElement('p');p.className='empty-copy';p.textContent='Чьё имя появится здесь первым?';rows.push(p);}$('recent').replaceChildren(...rows);}
  const hit=s.recent[0],old=previous?.recent[0];if(hit&&(!old||hit.received_at!==old.received_at||hit.id!==old.id||fresh)){const text=`${hit.name} открыл «${hit.guess}» +${hit.points}`;$('hit-toast').textContent=text;$('hit-toast').classList.remove('hidden');toastDeadline=Date.now()+3200;if(s.settings.sound&&!fresh)tone();}
  if(Date.now()>toastDeadline)$('hit-toast').classList.add('hidden');
  $('result').classList.toggle('hidden',phase!=='finished');
  if(phase==='finished'){
    $('result-title').textContent=s.winner?(s.result_type==='word'?'СЛОВО УГАДАНО!':'ПОБЕДА ПО ОЧКАМ'):'РАУНД ЗАВЕРШЁН';
    $('winner-name').textContent=s.winner?s.winner.name:'Попробуем ещё?';$('winner-picture').classList.toggle('hidden',!s.winner);$('result-crown').classList.toggle('hidden',!s.winner);
    if(s.winner)picture($('winner-picture'),s.winner);$('winner-points').textContent=s.winner?`${s.winner.score} очк. за раунд`:'';$('answer').textContent=s.answer;$('result-reason').textContent=s.result_reason;
    $('result-demo').classList.toggle('hidden',!s.demo);$('next-round').textContent=s.next_in!==null?`Следующий раунд через ${Math.ceil(s.next_in)} сек.`:'Следующее слово выбирает ведущий';
    if(previous&&previous.phase!=='finished'&&s.settings.sound){tone(660,.2);setTimeout(()=>tone(880,.3),150);}
  }
  $('footer-status').textContent=s.demo?'ДЕМО / ТЕСТОВЫЕ ИГРОКИ':s.connection==='online'?'Е И Ё СЧИТАЮТСЯ ОДНОЙ БУКВОЙ':'ЖДЁМ ПОДКЛЮЧЕНИЯ ЧАТА';previous=s;
}
function connect(){socket=new WebSocket(location.origin.replace('http','ws')+'/ws');socket.onopen=()=>socket.send(JSON.stringify({}));socket.onmessage=e=>render(JSON.parse(e.data));socket.onclose=()=>{notice('Связь с приложением потеряна. Переподключаемся…');setTimeout(connect,1200);};}connect();
