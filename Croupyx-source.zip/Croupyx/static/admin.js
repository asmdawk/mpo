'use strict';
const $=id=>document.getElementById(id);
let key=location.hash.slice(1)||sessionStorage.getItem('croupyx-key')||'';
if(key){sessionStorage.setItem('croupyx-key',key);history.replaceState(null,'','/');}
else $('auth-warning').classList.remove('hidden');
let state=null,toastTimer,settingsLoaded=false,settingsDirty=false,socket;
const phases={idle:'ГОТОВ К СТАРТУ',playing:'РАУНД ИДЁТ',paused:'ПАУЗА',finished:'РАУНД ЗАВЕРШЁН'};
function toast(text,error=false){const el=$('toast');el.textContent=text;el.classList.remove('hidden');el.classList.toggle('error',error);clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),6500);}
async function command(action,extra={}){try{const r=await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Croupyx-Key':key},body:JSON.stringify({action,...extra})});const data=await r.json().catch(()=>({error:'Откройте пульт через Croupyx.exe'}));if(!r.ok)throw new Error(data.error||'Команда не выполнена');return true;}catch(e){toast(e.message,true);return false;}}
document.querySelectorAll('[data-tab]').forEach(button=>button.onclick=()=>{document.querySelectorAll('[data-tab]').forEach(el=>el.classList.toggle('active',el===button));document.querySelectorAll('.tab').forEach(el=>el.classList.toggle('hidden',el.id!=='tab-'+button.dataset.tab));$('page-title').textContent=button.querySelector('span').textContent;resizePreview();});
$('connect').onclick=()=>command(state&&state.connection!=='offline'?'disconnect':'connect');
async function start(action){if(await command(action,{word:$('custom-word').value.trim()}))$('custom-word').value='';}
$('start').onclick=()=>start('start');$('demo').onclick=()=>start('demo');$('pause').onclick=()=>command('pause');$('resume').onclick=()=>command('resume');
$('finish').onclick=()=>{if(confirm('Завершить раунд и выбрать победителя по текущим очкам?'))command('finish');};
$('reset').onclick=()=>{if(confirm('Сбросить раунд и очки?'))command('reset');};
$('quit').onclick=async()=>{if(confirm('Завершить игру и отключить чат?')){if(await command('shutdown'))toast('Приложение завершено. Вкладку можно закрыть.');}};
async function copyURL(){const url=location.origin+'/board';try{await navigator.clipboard.writeText(url);toast('Ссылка на табло скопирована');}catch{prompt('Скопируйте ссылку',url);}}
$('copy-url').onclick=copyURL;$('copy-help').onclick=copyURL;$('board-url').textContent=location.origin+'/board';
const form=$('settings-form');form.addEventListener('input',()=>settingsDirty=true);
form.onsubmit=async event=>{event.preventDefault();const data=Object.fromEntries(new FormData(form));for(const name of ['round_seconds','cooldown_ms','next_delay'])data[name]=Number(data[name]);for(const name of ['sound','auto_next'])data[name]=form.elements[name].checked;if(await command('settings',{settings:data})){settingsDirty=false;settingsLoaded=false;toast('Настройки сохранены');}};
function fillSettings(settings){for(const [name,value] of Object.entries(settings)){const el=form.elements[name];if(!el)continue;if(el.type==='checkbox')el.checked=value;else el.value=value;}settingsLoaded=true;}
function render(s){state=s;const online=s.connection==='online',busy=!['idle','finished'].includes(s.phase);
  $('service-dot').classList.toggle('online',online);$('service-status').textContent=online?'Чат Twitch подключён':s.demo&&busy?'Демонстрационный раунд':'Приложение работает';
  $('account-name').textContent=s.settings.channel;
  const labels={offline:'ОФЛАЙН',connecting:'ПОДКЛЮЧЕНИЕ',reconnecting:'ВОССТАНАВЛИВАЕМ',online:'ЧАТ ПОДКЛЮЧЁН'};
  $('connection-badge').textContent=labels[s.connection]||s.connection;$('connection-badge').classList.toggle('online',online);$('connection-note').textContent=s.connection_note||'';
  $('connect').textContent=s.connection==='offline'?'Подключить Twitch ↗':'Отключить Twitch';$('connect').disabled=s.demo&&busy;
  $('mode-badge').textContent=(s.demo?'ДЕМО · ':'')+phases[s.phase];$('mode-badge').classList.toggle('demo-badge',s.demo);
  $('start').textContent=s.phase==='finished'?'Следующий раунд ▶':'Начать раунд ▶';$('start').disabled=busy||!online;
  $('demo').disabled=busy||s.connection!=='offline';$('pause').disabled=s.phase!=='playing';$('resume').disabled=s.phase!=='paused';$('finish').disabled=!busy;$('reset').disabled=s.phase==='idle';$('custom-word').disabled=busy;
  $('secret-word').textContent=s.answer||'—';$('chip-time').textContent=s.settings.round_seconds+' секунд';$('chip-difficulty').textContent={mixed:'Разная длина',short:'4–6 букв',medium:'7–9 букв',long:'10–14 букв'}[s.settings.difficulty];
  $('messages').textContent=(s.messages_received||0).toLocaleString('ru');$('hits').textContent=(s.hits_received||0).toLocaleString('ru');$('last-message').textContent=s.last_message?new Date(s.last_message*1000).toLocaleTimeString('ru'):'ещё нет';
  const events=s.events||[],digest=JSON.stringify(events);if($('event-log').dataset.digest!==digest){$('event-log').dataset.digest=digest;$('event-log').replaceChildren(...events.map(e=>{const row=document.createElement('div'),time=document.createElement('time');time.textContent=e.time;row.append(time,document.createTextNode(e.text));return row;}));}
  const hd=JSON.stringify(s.history);if($('history').dataset.digest!==hd){const el=$('history');el.dataset.digest=hd;el.replaceChildren();if(!s.history.length)el.textContent='Первое слово ждёт своего чемпиона.';
    for(const item of s.history.slice(0,8)){const row=document.createElement('div');row.className='history-row';const name=document.createElement('span');name.className='history-name';name.textContent='♛ '+item.name;const word=document.createElement('span');word.className='history-word';word.textContent=item.answer;const score=document.createElement('span');score.textContent=item.score+' очк.';const badge=document.createElement('span');badge.className='badge';badge.textContent=(item.result_type==='word'?'СЛОВО':'ПО ОЧКАМ')+(item.demo?' · ДЕМО':'');const time=document.createElement('time');time.textContent=item.time;row.append(name,word,score,badge,time);el.append(row);}}
  if(!settingsLoaded&&!settingsDirty)fillSettings(s.settings);form.querySelector('button[type=submit]').disabled=busy||s.connection!=='offline';
}
function connect(){socket=new WebSocket(location.origin.replace('http','ws')+'/ws');socket.onopen=()=>socket.send(JSON.stringify({key}));socket.onmessage=e=>render(JSON.parse(e.data));socket.onclose=()=>{$('service-status').textContent='Связь с приложением потеряна';$('service-dot').classList.remove('online');for(const id of ['start','demo','pause','resume','finish','connect'])$(id).disabled=true;setTimeout(connect,1500);};}
function resizePreview(){const frame=document.querySelector('.preview-frame');frame.querySelector('iframe').style.transform=`scale(${frame.clientWidth/1920})`;}
new ResizeObserver(resizePreview).observe(document.querySelector('.preview-frame'));connect();
