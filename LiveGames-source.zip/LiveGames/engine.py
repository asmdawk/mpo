"""Deterministic game engine. No TikTok or UI dependency."""
from dataclasses import dataclass, asdict
import time


DEFAULTS = dict(username='gameslivex', join_seconds=10, level_seconds=30,
                max_players=12, levels=10, step=100, keyword='+', entry='comment',
                sound=True)


def validate_settings(data):
    result = DEFAULTS | data
    for key, lo, hi in [('join_seconds', 3, 120), ('level_seconds', 5, 300),
                        ('max_players', 2, 12), ('levels', 1, 10), ('step', 10, 100)]:
        value = result[key]
        if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
            raise ValueError(f'{key}: допустимо от {lo} до {hi}')
    import re
    username = str(result['username']).strip().lstrip('@')
    if not re.fullmatch(r'[\w.]{1,32}', username, flags=re.ASCII):
        raise ValueError('Введите ник TikTok без ссылки: например gameslivex')
    result['username'] = username
    result['keyword'] = str(result['keyword']).strip()[:30]
    if not result['keyword']:
        raise ValueError('Укажите слово для входа')
    if result['entry'] not in ('comment', 'follow'):
        raise ValueError('Неизвестный способ входа')
    result['sound'] = bool(result['sound'])
    return {key: result[key] for key in DEFAULTS}


@dataclass
class Player:
    id: str
    name: str
    handle: str = ''
    avatar: str = ''
    score: int = 0
    total: int = 0
    alive: bool = True
    reached_at: float = 0
    last_score_at: float = 0
    eliminated_level: int = 0


class Game:
    def __init__(self, settings=None, clock=time.monotonic):
        self.settings = validate_settings(settings or {})
        self.clock = clock
        self.history = []
        self.round_id = 0
        self.reset()

    def reset(self):
        self.phase = 'idle'
        self.players = {}
        self.level = 0
        self.deadline = 0
        self.paused_from = None
        self.remaining = 0
        self.pause_reason = ''
        self.winner = None
        self.result_reason = ''
        self.demo = False
        self.round_id += 1

    @property
    def target(self):
        return self.level * self.settings['step']

    @property
    def active(self):
        return [p for p in self.players.values() if p.alive]

    def start(self, demo=False):
        if self.phase not in ('idle', 'finished'):
            raise ValueError('Сначала завершите или сбросьте текущую игру')
        self.reset()
        self.demo = demo
        self.phase = 'lobby'
        self.deadline = self.clock() + self.settings['join_seconds']

    def join(self, uid, name, handle='', avatar=''):
        # Arrival at or after the deadline must never sneak into the lobby.
        self.tick()
        uid = str(uid)
        if self.phase != 'lobby' or not uid or uid in self.players:
            return False
        if len(self.players) >= self.settings['max_players']:
            return False
        self.players[uid] = Player(uid, str(name)[:60] or 'Игрок', str(handle)[:40], avatar)
        if len(self.players) == self.settings['max_players']:
            self.begin_level()
        return True

    def begin_level(self):
        if len(self.active) < 2:
            if len(self.active) == 1:
                self.finish(self.active[0], 'Единственный участник')
            else:
                self.phase = 'finished'
                self.result_reason = 'Никто не вошёл. Запустите новый набор.'
            return
        self.level += 1
        for p in self.active:
            p.score = 0
            p.reached_at = 0
            p.last_score_at = 0
        self.phase = 'playing'
        self.deadline = self.clock() + self.settings['level_seconds']

    def like(self, uid, count):
        self.tick()
        p = self.players.get(str(uid))
        if self.phase != 'playing' or not p or not p.alive:
            return False
        if isinstance(count, bool) or not isinstance(count, int) or count <= 0:
            return False
        # A packet counts toward exactly one level; excess isn't carried over.
        p.score += count
        p.total += count
        p.last_score_at = self.clock()
        if p.score >= self.target and not p.reached_at:
            p.reached_at = self.clock()
        if all(x.score >= self.target for x in self.active):
            self.end_level()
        return True

    def best(self, candidates):
        # Highest score, then earliest receipt of that score, then entry order.
        return max(candidates, key=lambda p: (p.score, -p.last_score_at))

    def end_level(self):
        active = self.active
        passed = [p for p in active if p.score >= self.target]
        if len(passed) == 1:
            for p in active:
                if p not in passed:
                    p.alive = False
                    p.eliminated_level = self.level
            self.finish(passed[0], 'Последний оставшийся игрок')
            return
        if not passed or self.level >= self.settings['levels']:
            self.finish(self.best(passed or active), 'Лучший результат уровня; при равенстве — кто набрал раньше')
            return
        for p in active:
            if p not in passed:
                p.alive = False
                p.eliminated_level = self.level
        # Short readable intermission instead of instantly clearing full bars.
        self.phase = 'between'
        self.deadline = self.clock() + 3

    def finish(self, winner, reason):
        for p in self.active:
            if p.id != winner.id:
                p.alive = False
                p.eliminated_level = self.level
        self.phase = 'finished'
        self.winner = winner.id
        self.result_reason = reason
        self.history.insert(0, dict(name=winner.name, total=winner.total,
                                    level=self.level, demo=self.demo,
                                    time=time.strftime('%d.%m %H:%M')))
        self.history = self.history[:30]

    def pause(self, reason='Пауза ведущего'):
        if self.phase in ('lobby', 'playing', 'between'):
            self.remaining = max(0, self.deadline - self.clock())
            self.paused_from = self.phase
            self.phase = 'paused'
            self.pause_reason = reason

    def resume(self):
        if self.phase == 'paused':
            self.phase = self.paused_from
            self.deadline = self.clock() + self.remaining
            self.pause_reason = ''

    def tick(self):
        if self.phase not in ('lobby', 'playing', 'between') or self.clock() < self.deadline:
            return
        if self.phase in ('lobby', 'between'):
            self.begin_level()
        else:
            self.end_level()

    def snapshot(self):
        remaining = self.remaining if self.phase == 'paused' else max(0, self.deadline - self.clock())
        return dict(phase=self.phase, level=self.level, target=self.target,
                    remaining=round(remaining, 2), players=[asdict(p) for p in self.players.values()],
                    winner=self.winner, result_reason=self.result_reason,
                    pause_reason=self.pause_reason, demo=self.demo,
                    round_id=self.round_id, history=self.history)
