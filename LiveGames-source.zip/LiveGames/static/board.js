'use strict';
const $=id=>document.getElementById(id);
const preview=new URLSearchParams(location.search).has('preview');
if(preview)document.body.classList.add('preview-mode');
let previous=null, socket, audio=null, soundEnabled=false, cards=new Map(), lastPhase='';
function tone(freq=660,length=.08){if(!soundEnabled||!audio||preview)return;const oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.connect(gain);gain.connect(audio.destination);oscillator.frequency.value=freq;gain.gain.setValueAtTime(.035,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+length);oscillator.start();oscillator.stop(audio.currentTime+length);}
$('enable-sound').onclick=()=>{audio=audio||new AudioContext();audio.resume();soundEnabled=!soundEnabled;$('enable-sound').textContent=soundEnabled?'♫ Звук включён':'♫ Включить звук';tone();};
$('fullscreen').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen().catch(()=>{});};
function avatar(element,p){const url=p.avatar||'';element.replaceChildren();const fallback=()=>{element.replaceChildren(document.createTextNode(p.name.slice(0,2).toUpperCase()));};
  // Only safe image protocols. External images never become HTML.
  if(url.startsWith('https://')||url.startsWith('/static/')){const img=document.createElement('img');img.alt='';img.referrerPolicy='no-referrer';img.src=url;img.onerror=fallback;element.append(img);}else fallback();
}
function makeCard(p){const card=document.createElement('article');card.className='player-card joined';card.dataset.id=p.id;
  const picture=document.createElement('div');picture.className='avatar-wrap';avatar(picture,p);
  const name=document.createElement('div');name.className='player-name';name.textContent=p.name;
  const row=document.createElement('div');row.className='progress-row';const track=document.createElement('div');track.className='progress-track';const fill=document.createElement('div');fill.className='progress-fill';track.append(fill);const count=document.createElement('span');count.className='progress-count';row.append(track,count);
  const out=document.createElement('div');out.className='out-label hidden';out.textContent='ВЫБЫЛ';const status=document.createElement('div');status.className='slot-status hidden';status.textContent='Готов к игре';
  card.append(picture,name,row,out,status);return card;
}
function showNotice(message){$('board-notice').textContent=message;$('board-notice').classList.toggle('hidden',!message);}
function render(s){
  const phase=s.phase, cfg=s.settings, lobby=phase==='lobby',idle=phase==='idle',playing=phase==='playing',between=phase==='between',paused=phase==='paused';
  const newRound=!previous||s.round_id!==previous.round_id;
  if(newRound){cards.clear();$('player-grid').replaceChildren();}
  if(previous&&cfg.sound&&previous.round_id===s.round_id){if(s.players.length>previous.players.length)tone(780);if(s.level>previous.level)tone(990,.18);if(phase==='finished'&&previous.phase!=='finished'){tone(660,.25);setTimeout(()=>tone(880,.35),170);}}
  $('board-account').textContent='@'+cfg.username;
  $('board-mode').textContent=s.demo?'ДЕМО • ТЕСТОВЫЕ ИГРОКИ':s.connection==='online'?'● LIVE GAME':'LIVEGAMES';$('board-mode').classList.toggle('demo-badge',s.demo);
  const entry=cfg.entry==='follow'?'Подпишись во время набора':`Напиши «${cfg.keyword}» в чат`;
  $('level-label').textContent=idle||lobby?'НАБОР УЧАСТНИКОВ':paused?'ИГРА ПРИОСТАНОВЛЕНА':'ТЕКУЩИЙ УРОВЕНЬ';
  $('board-level').textContent=idle?'ЖДЁМ СТАРТА':lobby?`${s.players.length} / ${cfg.max_players} ИГРОКОВ`:`${s.level} / ${cfg.levels}`;
  $('goal-label').textContent=idle||lobby?'ВХОД В ИГРУ':between?'ПРОЙДЕНО':'ЦЕЛЬ УРОВНЯ';
  $('board-goal').textContent=idle||lobby?entry:between?'Следующий уровень →':`${s.target} ЛАЙКОВ`;
  $('timer-label').textContent=lobby?'ДО НАЧАЛА':between?'НОВЫЙ УРОВЕНЬ':paused?'ОСТАЛОСЬ':'ДО КОНЦА';
  const seconds=Math.max(0,Math.ceil(s.remaining));$('board-timer').textContent=idle||phase==='finished'?'—':String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');
  document.querySelector('.timer-box').classList.toggle('urgent',seconds<=5&&!idle);
  $('board-count').textContent=`${s.players.filter(p=>p.alive).length} / ${cfg.max_players}`;
  const winner=s.players.find(p=>p.id===s.winner);$('winner-screen').classList.toggle('hidden',phase!=='finished'||!winner);
  if(winner&&phase==='finished'){
    if(!previous||previous.winner!==s.winner||newRound)avatar($('winner-avatar'),winner);
    $('winner-name').textContent=winner.name;$('winner-score').textContent=`${winner.total.toLocaleString('ru')} лайков за игру · уровень ${s.level}`;
    $('winner-reason').textContent=s.result_reason;$('winner-demo').classList.toggle('hidden',!s.demo);
  }
  let notice=paused?s.pause_reason:phase==='finished'&&!winner?s.result_reason:'';
  if(s.connection!=='online'&&!s.demo&&!idle&&phase!=='finished')notice=notice||'Связь с TikTok восстанавливается';
  showNotice(notice);
  const grid=$('player-grid');
  grid.querySelectorAll('.empty-slot').forEach(el=>el.remove());
  for(const p of s.players){let card=cards.get(p.id);if(!card){card=makeCard(p);cards.set(p.id,card);grid.append(card);}
    const passed=p.alive&&s.target>0&&p.score>=s.target;
    card.classList.toggle('passed',passed);card.classList.toggle('eliminated',!p.alive);
    card.querySelector('.progress-fill').style.width=`${s.target?Math.min(100,p.score/s.target*100):0}%`;
    card.querySelector('.progress-count').textContent=`${p.score}/${s.target}`;
    card.querySelector('.progress-row').classList.toggle('hidden',!p.alive||idle||lobby);
    card.querySelector('.out-label').classList.toggle('hidden',p.alive);
    card.querySelector('.slot-status').classList.toggle('hidden',!(lobby||idle));
  }
  for(let i=s.players.length;i<cfg.max_players;i++){const empty=document.createElement('article');empty.className='player-card empty-slot';const number=document.createElement('span');number.className='slot-number';number.textContent=String(i+1).padStart(2,'0');const label=document.createElement('p');label.textContent=lobby?'ЖДЁМ ИГРОКА':'СВОБОДНОЕ МЕСТО';empty.append(number,label);grid.append(empty);}
  const ladder=$('level-ladder');const signature=`${s.level}:${cfg.levels}`;if(ladder.dataset.signature!==signature){ladder.dataset.signature=signature;ladder.replaceChildren();for(let i=1;i<=cfg.levels;i++){const el=document.createElement('span');el.className='level-step'+(i<s.level?' done':i===s.level?' current':'');el.textContent=i<s.level?'✓':i;el.title=`Уровень ${i}: ${i*cfg.step} лайков`;ladder.append(el);}}
  previous=s;
}
function connect(){socket=new WebSocket(location.origin.replace('http','ws')+'/ws');socket.onopen=()=>socket.send(JSON.stringify({}));socket.onmessage=e=>render(JSON.parse(e.data));socket.onclose=()=>{showNotice('Связь с приложением потеряна. Переподключаемся…');setTimeout(connect,1200);};}
connect();
