'use strict';
const $ = id => document.getElementById(id);
let key = location.hash.slice(1) || sessionStorage.getItem('livegames-key') || '';
if (key) { sessionStorage.setItem('livegames-key', key); history.replaceState(null, '', '/'); }
else $('auth-warning').classList.remove('hidden');
let state = null, toastTimer, settingsLoaded = false, socket, settingsDirty = false;
const phaseLabels = {idle:'ГОТОВ К СТАРТУ',lobby:'НАБОР ИГРОКОВ',playing:'ИГРА ИДЁТ',between:'СЛЕДУЮЩИЙ УРОВЕНЬ',paused:'ПАУЗА',finished:'РАУНД ЗАВЕРШЁН'};
function toast(message, error=false) { const el=$('toast'); el.textContent=message;el.classList.remove('hidden');el.classList.toggle('error',error);clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.add('hidden'),6500); }
async function command(action, extra={}) {
  try { const response = await fetch('/api', {method:'POST',headers:{'Content-Type':'application/json','X-LiveGames-Key':key},body:JSON.stringify({action,...extra})});
    const data=await response.json().catch(()=>({error:'Нет доступа. Откройте панель через LiveGames.exe.'}));
    if (!response.ok) throw new Error(data.error||'Не удалось выполнить команду');
    return true;
  } catch(error) { toast(error.message,true); return false; }
}
document.querySelectorAll('[data-tab]').forEach(button => button.addEventListener('click',()=>{
  document.querySelectorAll('[data-tab]').forEach(el=>el.classList.toggle('active',el===button));
  document.querySelectorAll('.tab').forEach(el=>el.classList.toggle('hidden',el.id!=='tab-'+button.dataset.tab));
  $('page-title').textContent=button.textContent.trim().slice(1).trim();resizePreview();
}));
$('connect').onclick=()=>command(state && !['offline'].includes(state.connection)?'disconnect':'connect');
$('start').onclick=()=>command('start'); $('demo').onclick=()=>command('demo');
$('pause').onclick=()=>command('pause'); $('resume').onclick=()=>command('resume');
$('reset').onclick=()=>{if(confirm('Сбросить текущую игру и очистить места?'))command('reset');};
$('quit').onclick=async()=>{if(confirm('Завершить приложение? Игра и подключение к эфиру остановятся.')){if(await command('shutdown'))toast('Приложение завершено. Вкладку можно закрыть.');}};
async function copyURL(){const url=location.origin+'/board';try{await navigator.clipboard.writeText(url);toast('Ссылка на табло скопирована');}catch{prompt('Скопируйте ссылку:',url);}}
$('copy-url').onclick=copyURL;$('copy-help').onclick=copyURL;$('board-url').textContent=location.origin+'/board';
const form=$('settings-form');form.addEventListener('input',()=>settingsDirty=true);
form.onsubmit=async event=>{event.preventDefault();const data=Object.fromEntries(new FormData(form));
  for(const name of ['join_seconds','level_seconds','max_players','levels','step'])data[name]=Number(data[name]);
  data.sound=form.elements.sound.checked;
  if(await command('settings',{settings:data})){settingsDirty=false;settingsLoaded=false;toast('Настройки сохранены');}
};
function fillSettings(settings){for(const [name,value] of Object.entries(settings)){const el=form.elements[name];if(!el)continue;if(el.type==='checkbox')el.checked=value;else el.value=value;}settingsLoaded=true;}
function render(s){state=s;const online=s.connection==='online';const busy=!['idle','finished'].includes(s.phase);
  $('service-dot').classList.toggle('online',online);$('service-status').textContent=online?'TikTok подключён':s.demo&&busy?'Демонстрационная игра':'Приложение работает';
  $('account-name').textContent='@'+s.settings.username;
  const labels={offline:'ОФЛАЙН',connecting:'ПОДКЛЮЧЕНИЕ',reconnecting:'ПЕРЕПОДКЛЮЧЕНИЕ',online:'В ЭФИРЕ'};
  const badge=$('connection-badge');badge.textContent=labels[s.connection]||s.connection;badge.classList.toggle('online',online);
  $('connection-note').textContent=s.connection_note||'';
  $('connect').textContent=s.connection==='offline'?'Привязать к TikTok ↗':'Отключить TikTok';
  $('connect').disabled=s.demo&&busy;
  $('mode-badge').textContent=(s.demo?'ДЕМО · ':'')+phaseLabels[s.phase];$('mode-badge').classList.toggle('demo-badge',s.demo);
  $('start').disabled=busy||!online; $('demo').disabled=busy||s.connection!=='offline';
  $('pause').disabled=!['lobby','playing','between'].includes(s.phase);$('resume').disabled=s.phase!=='paused';
  $('reset').disabled=s.phase==='idle';
  $('chip-join').textContent=s.settings.join_seconds+' сек на вход';$('chip-capacity').textContent='до '+s.settings.max_players+' игроков';$('chip-levels').textContent=s.settings.levels+' уровней';
  $('packets').textContent=(s.like_packets||0).toLocaleString('ru');$('likes').textContent=(s.received_likes||0).toLocaleString('ru');
  $('last-like').textContent=s.last_like?new Date(s.last_like*1000).toLocaleTimeString('ru'):'ещё нет';
  const events=s.events||[];const digest=JSON.stringify(events);if($('event-log').dataset.digest!==digest){$('event-log').dataset.digest=digest;$('event-log').replaceChildren(...events.map(e=>{const row=document.createElement('div');const time=document.createElement('time');time.textContent=e.time;row.append(time,document.createTextNode(e.text));return row;}));}
  const hd=JSON.stringify(s.history);if($('history').dataset.digest!==hd){const el=$('history');el.dataset.digest=hd;el.replaceChildren();if(!s.history.length)el.textContent='Первый чемпион ещё впереди.';
    for(const item of s.history.slice(0,8)){const row=document.createElement('div');row.className='history-row';const name=document.createElement('span');name.className='history-name';name.textContent='♛ '+item.name;const score=document.createElement('span');score.textContent=item.total.toLocaleString('ru')+' лайков';const level=document.createElement('span');level.className='badge';level.textContent='LVL '+item.level+(item.demo?' · ДЕМО':'');const time=document.createElement('time');time.textContent=item.time;row.append(name,score,level,time);el.append(row);}}
  if(!settingsLoaded&&!settingsDirty)fillSettings(s.settings);
  form.querySelector('button[type=submit]').disabled=busy||s.connection!=='offline';
}
function connect(){socket=new WebSocket(location.origin.replace('http','ws')+'/ws');socket.onopen=()=>socket.send(JSON.stringify({key}));socket.onmessage=event=>render(JSON.parse(event.data));socket.onclose=()=>{$('service-status').textContent='Связь с приложением потеряна';$('service-dot').classList.remove('online');for(const id of ['start','demo','pause','resume','connect'])$(id).disabled=true;setTimeout(connect,1500);};}
function resizePreview(){const frame=document.querySelector('.preview-frame');const iframe=frame.querySelector('iframe');iframe.style.transform=`scale(${frame.clientWidth/1920})`;}
new ResizeObserver(resizePreview).observe(document.querySelector('.preview-frame'));connect();
