import os
from pathlib import Path
import sys
import tempfile
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ['LIVEGAMES_DATA'] = tempfile.mkdtemp(prefix='livegames-test-')
from app import Service
from TikTokLive.proto.custom_proto import ExtendedUser
from TikTokLive.events import LikeEvent, CommentEvent, FollowEvent
from TikTokLiveProto.v3.webcast.shared.message import CommonMessageData
from TikTokLiveProto.v3.webcast.model.base import ImageModel


def user(i=1):
    return ExtendedUser(id=i, nickname=f'Игрок {i}', display_id=f'player{i}',
                        avatar_thumb=ImageModel(url_list=['https://example.com/avatar.png']))


def service():
    s = Service()
    s.game.settings['max_players'] = 2
    s.game.start()
    return s


def test_real_proto_identity_and_comment_entry():
    s=service()
    s.handle_comment(CommentEvent(user=user(), content='+'))
    p=s.game.players['1']
    assert p.name=='Игрок 1' and p.handle=='player1'
    assert p.avatar=='https://example.com/avatar.png'


def test_real_proto_like_batch_and_deduplication():
    s=service();s.enter(user(1));s.enter(user(2))
    event=LikeEvent(user=user(), count=8, total=123456,
                    common=CommonMessageData(msg_id=777))
    s.handle_like(event);s.handle_like(event)
    assert s.game.players['1'].score==8 and s.like_packets==1
    s.handle_like(LikeEvent(user=user(),count=2,common=CommonMessageData(msg_id=778)))
    assert s.game.players['1'].score==10


def test_follow_entry_and_mismatched_keyword():
    s=service();s.handle_comment(CommentEvent(user=user(),content='другой текст'))
    assert not s.game.players
    s.game.settings['entry']='follow'
    s.handle_follow(FollowEvent(user=user()))
    assert '1' in s.game.players


def test_connection_loss_pauses_and_does_not_resume_automatically():
    s=service();s.enter(user(1));s.enter(user(2));s.connection_lost('test')
    assert s.game.phase=='paused'
    s.connection='online'
    s.handle_like(LikeEvent(user=user(),count=100))
    assert s.game.players['1'].score==0 and s.game.phase=='paused'


def test_events_without_identity_cannot_enter():
    s=service();s.enter(None);s.enter(ExtendedUser())
    assert not s.game.players


def test_live_events_do_not_contaminate_demo():
    s=service();s.game.reset();s.game.start(demo=True)
    s.handle_comment(CommentEvent(user=user(),content='+'))
    assert not s.game.players
