import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
from engine import Game, validate_settings


class Clock:
    def __init__(self): self.now = 100.0
    def __call__(self): return self.now
    def advance(self, n): self.now += n


def setup_game(capacity=3, **settings):
    clock = Clock()
    game = Game(dict(max_players=capacity, **settings), clock)
    game.start()
    return game, clock


def filled(capacity=3, **settings):
    game, clock = setup_game(capacity, **settings)
    for i in range(capacity): game.join(str(i), f'Player {i}')
    return game, clock


def test_capacity_and_early_start():
    g, c = filled(12)
    assert len(g.players) == 12 and g.phase == 'playing'
    assert not g.join('99', 'Late')


def test_no_duplicate_entries():
    g, c = setup_game()
    assert g.join('1', 'A')
    assert not g.join('1', 'B')
    assert len(g.players) == 1


def test_lobby_deadline_rejects_late_join():
    g, c = setup_game()
    g.join('1','A'); g.join('2','B')
    c.advance(10)
    assert not g.join('3', 'Late')
    assert g.phase == 'playing'


def test_empty_lobby_and_one_player():
    g,c=setup_game();c.advance(10);g.tick()
    assert g.phase == 'finished' and g.winner is None
    g.start();g.join('a','A');c.advance(10);g.tick()
    assert g.phase == 'finished' and g.winner == 'a'


def test_count_is_packet_delta_not_room_total():
    g,c=filled();g.like('0',7);g.like('0',5)
    assert g.players['0'].score == 12
    assert not g.like('unknown', 900)


@pytest.mark.parametrize('count', [0,-1,True,1.5,'20'])
def test_invalid_likes_ignored(count):
    g,c=filled();assert not g.like('0',count)
    assert g.players['0'].score == 0


def test_elimination_and_reset_per_level():
    g,c=filled();g.like('0',100);g.like('1',110);c.advance(30);g.tick()
    assert g.phase == 'between'
    assert not g.players['2'].alive
    c.advance(3);g.tick()
    assert g.level == 2 and g.target == 200
    assert g.players['1'].score == 0 and g.players['1'].total == 110
    assert not g.like('2',999)


def test_pause_freezes_and_ignores_likes():
    g,c=filled();c.advance(9);g.pause();remaining=g.remaining
    c.advance(600);g.tick();assert not g.like('0',100)
    assert g.phase=='paused'
    g.resume();assert g.deadline==c.now+remaining
    c.advance(remaining);g.tick();assert g.phase=='finished'


def test_one_survivor():
    g,c=filled();g.like('1',100);c.advance(30);g.tick()
    assert g.winner=='1' and g.phase=='finished'


def test_no_passers_best_score_wins():
    g,c=filled();g.like('0',70);g.like('1',80);c.advance(30);g.tick()
    assert g.winner=='1'


def test_tie_earliest_score_wins():
    g,c=filled();g.like('1',70);c.advance(1);g.like('0',70);c.advance(29);g.tick()
    assert g.winner=='1'


def test_all_zero_tie_uses_entry_order():
    g,c=filled();c.advance(30);g.tick();assert g.winner=='0'


def test_late_packet_does_not_save_player():
    g,c=filled();g.like('0',100);c.advance(30)
    assert not g.like('1',200)
    assert g.winner=='0'


def test_all_pass_early_intermission():
    g,c=filled(2);g.like('0',100);g.like('1',100)
    assert g.phase=='between'
    assert not g.like('0',300)
    c.advance(3);g.tick();assert g.target==200 and g.players['0'].score==0


def test_ten_levels_maximum_and_single_winner():
    g,c=filled(2)
    for level in range(1,11):
        assert g.level==level
        g.like('0',level*100);c.advance(.1);g.like('1',level*100)
        if level<10: c.advance(3);g.tick()
    assert g.phase=='finished' and g.level==10 and g.winner=='0'
    assert g.players['0'].total==5500


def test_settings_bounds():
    for bad in [dict(levels=11),dict(max_players=13),dict(username='https://bad'),dict(level_seconds=0),dict(keyword='')]:
        with pytest.raises(ValueError): validate_settings(bad)


def test_reset_preserves_history_and_clears_round():
    g,c=filled(2);g.like('0',40);c.advance(30);g.tick();g.reset()
    assert g.phase=='idle' and not g.players and len(g.history)==1


def test_during_lobby_likes_ignored():
    g,c=setup_game();g.join('1','A');assert not g.like('1',500)


def test_cannot_restart_active_round():
    g,c=filled()
    with pytest.raises(ValueError): g.start()
