#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <shlobj.h>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include "vendor/miniz/miniz.h"

#ifndef BUILD_ID
#define BUILD_ID L"1.0.0"
#endif

static void error(const wchar_t *message) {
    MessageBoxW(NULL, message, L"LiveGames", MB_ICONERROR | MB_OK);
}

static BOOL launch(wchar_t *application, wchar_t *command, wchar_t *directory, BOOL wait) {
    STARTUPINFOW si = {0}; PROCESS_INFORMATION pi = {0};
    si.cb = sizeof(si); si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
    if (!CreateProcessW(application, command, NULL, NULL, FALSE, CREATE_NO_WINDOW,
                        NULL, directory, &si, &pi)) return FALSE;
    if (wait) {
        DWORD status;
        while (WaitForSingleObject(pi.hProcess, 50) == WAIT_TIMEOUT) {
            MSG msg;
            while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) {
                TranslateMessage(&msg); DispatchMessageW(&msg);
            }
        }
        GetExitCodeProcess(pi.hProcess, &status);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        return status == 0;
    }
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread); return TRUE;
}


static BOOL unpack(const void *bytes, DWORD length, const wchar_t *directory, HWND splash) {
    mz_zip_archive archive = {0};
    if (!mz_zip_reader_init_mem(&archive, bytes, length, 0)) return FALSE;
    BOOL ok = TRUE;
    mz_uint count = mz_zip_reader_get_num_files(&archive);
    for (mz_uint i=0; i<count && ok; i++) {
        mz_zip_archive_file_stat stat;
        if (!mz_zip_reader_file_stat(&archive,i,&stat)) { ok=FALSE; break; }
        const char *name=stat.m_filename;
        if (!*name || *name=='/' || *name=='\\' || strstr(name,"..") || strchr(name,':')) { ok=FALSE; break; }
        wchar_t relative[MAX_PATH], dest[MAX_PATH], parent[MAX_PATH];
        if (!MultiByteToWideChar(CP_UTF8,MB_ERR_INVALID_CHARS,name,-1,relative,MAX_PATH)) { ok=FALSE; break; }
        for(wchar_t *c=relative; *c; c++) if(*c=='/')*c='\\';
        if(wcslen(directory)+wcslen(relative)+2>=MAX_PATH) {ok=FALSE;break;}
        swprintf(dest,MAX_PATH,L"%ls\\%ls",directory,relative);
        if (mz_zip_reader_is_file_a_directory(&archive,i)) {
            SHCreateDirectoryExW(NULL,dest,NULL); continue;
        }
        wcscpy(parent,dest);
        wchar_t *slash=wcsrchr(parent,'\\'); if(slash)*slash=0;
        SHCreateDirectoryExW(NULL,parent,NULL);
        size_t size=0;
        void *data=mz_zip_reader_extract_to_heap(&archive,i,&size,0);
        if(!data || size>0xffffffffUL) {if(data)mz_free(data);ok=FALSE;break;}
        HANDLE file=CreateFileW(dest,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
        DWORD written=0;
        if(file==INVALID_HANDLE_VALUE || !WriteFile(file,data,(DWORD)size,&written,NULL) || written!=size)ok=FALSE;
        if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);
        mz_free(data);
        if(i%30==0){
            wchar_t text[120];swprintf(text,120,L"LIVEGAMES\nПервый запуск: готовим приложение… %u%%",(unsigned)(i*100/count));
            SetWindowTextW(splash,text);
            MSG msg;while(PeekMessageW(&msg,NULL,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessageW(&msg);}
        }
    }
    mz_zip_reader_end(&archive);
    return ok;
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, PWSTR line, int show) {
    (void)previous; (void)line; (void)show;
    wchar_t local[MAX_PATH], install[MAX_PATH], ready[MAX_PATH];
    wchar_t python[MAX_PATH], app[MAX_PATH], command[MAX_PATH * 3];
    HANDLE lock = CreateMutexW(NULL, FALSE, L"Local\\LiveGames.Extract.1");
    DWORD lock_result = lock ? WaitForSingleObject(lock, 120000) : WAIT_FAILED;
    if (lock_result != WAIT_OBJECT_0 && lock_result != WAIT_ABANDONED) {
        error(L"Не удалось подготовить приложение. Попробуйте запустить снова."); return 1;
    }
    if (FAILED(SHGetFolderPathW(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, local))) {
        error(L"Не удалось найти папку профиля Windows."); return 1;
    }
    if (wcslen(local) > 160) { error(L"Путь профиля Windows слишком длинный."); return 1; }
    swprintf(install, MAX_PATH, L"%ls\\LiveGames\\app-%ls", local, BUILD_ID);
    if (SHCreateDirectoryExW(NULL, install, NULL) != ERROR_SUCCESS && GetFileAttributesW(install) == INVALID_FILE_ATTRIBUTES) {
        error(L"Не удалось создать папку LiveGames в профиле Windows."); return 1;
    }
    swprintf(ready, MAX_PATH, L"%ls\\ready.txt", install);
    swprintf(python, MAX_PATH, L"%ls\\pythonw.exe", install);
    swprintf(app, MAX_PATH, L"%ls\\app.py", install);
    if (GetFileAttributesW(ready) == INVALID_FILE_ATTRIBUTES || GetFileAttributesW(python) == INVALID_FILE_ATTRIBUTES || GetFileAttributesW(app) == INVALID_FILE_ATTRIBUTES) {
        HRSRC resource = FindResourceW(instance, MAKEINTRESOURCEW(101), RT_RCDATA);
        if (!resource) { error(L"Повреждён файл приложения: не найден встроенный пакет."); return 1; }
        DWORD length = SizeofResource(instance, resource);
        const void *bytes = LockResource(LoadResource(instance, resource));
        HWND splash = CreateWindowExW(WS_EX_TOPMOST, L"STATIC", L"LIVEGAMES\nПервый запуск: готовим приложение…\nЭто может занять до минуты.",
                        WS_POPUP | WS_BORDER | SS_CENTER, (GetSystemMetrics(SM_CXSCREEN)-520)/2,
                        (GetSystemMetrics(SM_CYSCREEN)-130)/2, 520,130,NULL,NULL,instance,NULL);
        ShowWindow(splash,SW_SHOW);UpdateWindow(splash);
        BOOL ok=unpack(bytes,length,install,splash);
        DestroyWindow(splash);
        if (!ok) { error(L"Не удалось распаковать встроенный Python. Проверьте свободное место на диске и запустите приложение снова."); return 1; }
        HANDLE file=CreateFileW(ready,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
        if(file!=INVALID_HANDLE_VALUE)CloseHandle(file);
    }
    ReleaseMutex(lock);CloseHandle(lock);
    swprintf(command,MAX_PATH*3,L"\"%ls\" \"%ls\"",python,app);
    if (!launch(python,command,install,FALSE)) {
        error(L"Не удалось запустить встроенный Python. Требуется Windows 10/11 x64."); return 1;
    }
    return 0;
}
