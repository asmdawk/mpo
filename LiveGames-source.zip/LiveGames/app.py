"""LiveGames desktop service. Binds loopback only; public display is read-only."""
import asyncio
import contextlib
import hashlib
import json
import logging
import os
from pathlib import Path
import random
import secrets
import sys
import time
import webbrowser
from collections import OrderedDict, deque
from urllib.parse import urlsplit
from aiohttp import web
from engine import Game, validate_settings

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('LIVEGAMES_DATA', str(Path(os.environ.get('LOCALAPPDATA', str(ROOT))) / 'LiveGames' / 'data')))
DATA.mkdir(parents=True, exist_ok=True)
PORT = int(os.environ.get('LIVEGAMES_PORT', '17891'))
BASE = f'http://127.0.0.1:{PORT}'
TOKEN_PATH = DATA / 'admin.key'
if not TOKEN_PATH.exists():
    TOKEN_PATH.write_text(secrets.token_urlsafe(32), encoding='ascii')
TOKEN = TOKEN_PATH.read_text(encoding='ascii').strip()
logging.basicConfig(filename=DATA / 'livegames.log', level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')


class Service:
    def __init__(self):
        self.config_path = DATA / 'settings.json'
        try:
            settings = validate_settings(json.loads(self.config_path.read_text('utf-8')))
        except (OSError, ValueError, TypeError):
            settings = None
        self.game = Game(settings)
        try:
            self.game.history = json.loads((DATA / 'history.json').read_text('utf-8'))[:30]
        except (OSError, ValueError, TypeError):
            pass
        self.peers = set()
        self.connection = 'offline'
        self.connection_note = 'Подключите эфир или запустите демо'
        self.desired = False
        self.client = None
        self.connect_task = None
        self.events = deque(maxlen=60)
        self.seen = OrderedDict()
        self.like_packets = 0
        self.received_likes = 0
        self.last_event = None
        self.last_like = None
        self.demo_next_join = 0
        self.demo_next_like = 0
        self.demo_rates = {}
        self.stopping = asyncio.Event()
        self.last_history = ''
        self.last_digest = ''

    def log(self, text):
        self.events.appendleft({'time': time.strftime('%H:%M:%S'), 'text': str(text)[:250]})

    def connection_lost(self, note):
        self.connection = 'reconnecting' if self.desired else 'offline'
        self.connection_note = note
        if not self.game.demo:
            self.game.pause('Связь с TikTok прервана. Восстановите подключение и нажмите «Продолжить».')

    def duplicate(self, event, kind):
        common = getattr(event, 'common', None) or getattr(event, 'base_message', None)
        mid = getattr(common, 'msg_id', 0) or getattr(common, 'message_id', 0)
        if not mid:
            return False
        key = (kind, str(mid))
        if key in self.seen:
            return True
        self.seen[key] = True
        if len(self.seen) > 20000:
            self.seen.popitem(last=False)
        return False

    def identity(self, user):
        uid = str(getattr(user, 'id', '') or getattr(user, 'id_str', ''))
        handle = getattr(user, 'unique_id', '') or getattr(user, 'username', '')
        name = getattr(user, 'nickname', '') or getattr(user, 'nick_name', '') or handle or 'Игрок'
        urls = getattr(getattr(user, 'avatar_thumb', None), 'url_list', [])
        avatar = next((u for u in urls if isinstance(u, str) and u.startswith('https://')), '')
        return uid, name, handle, avatar

    def enter(self, user):
        if self.game.demo:
            return
        uid, name, handle, avatar = self.identity(user)
        if uid and uid != '0' and self.game.join(uid, name, handle, avatar):
            self.log(f'{name} вошёл в игру')

    def handle_comment(self, event):
        self.last_event = time.time()
        if not self.duplicate(event, 'comment') and self.game.settings['entry'] == 'comment':
            if event.comment.strip().casefold() == self.game.settings['keyword'].casefold():
                self.enter(event.user)

    def handle_follow(self, event):
        self.last_event = time.time()
        if not self.duplicate(event, 'follow') and self.game.settings['entry'] == 'follow':
            self.enter(event.user)

    def handle_like(self, event):
        self.last_event = self.last_like = time.time()
        if self.duplicate(event, 'like'):
            return
        count = int(event.count)
        self.like_packets += 1
        self.received_likes += max(0, count)
        if not self.game.demo:
            self.game.like(self.identity(event.user)[0], count)

    async def connect(self):
        from TikTokLive import TikTokLiveClient
        from TikTokLive.events import ConnectEvent, DisconnectEvent, LikeEvent, CommentEvent, FollowEvent
        attempt = 0
        while self.desired:
            self.connection = 'connecting' if attempt == 0 else 'reconnecting'
            self.connection_note = 'Ищем прямой эфир…' if attempt == 0 else 'Повторное подключение…'
            self.client = client = TikTokLiveClient(unique_id='@' + self.game.settings['username'])

            @client.on(ConnectEvent)
            async def connected(event):
                nonlocal attempt
                attempt = 0
                self.connection = 'online'
                self.connection_note = 'Эфир подключён • ждём события'
                self.log('Подключение к TikTok установлено')

            @client.on(DisconnectEvent)
            async def disconnected(event):
                self.connection_lost('Соединение прервано. Переподключаемся…')

            @client.on(CommentEvent)
            async def comment(event):
                self.handle_comment(event)

            @client.on(FollowEvent)
            async def follow(event):
                self.handle_follow(event)

            @client.on(LikeEvent)
            async def like(event):
                self.handle_like(event)

            try:
                task = await asyncio.wait_for(client.start(fetch_room_info=False, fetch_gift_info=False), 35)
                await task
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logging.exception('TikTok connection failed')
                code = type(exc).__name__
                if 'UserOffline' in code or 'LiveNotFound' in code:
                    note = 'Аккаунт сейчас не в эфире. Запустите LIVE Studio.'
                elif 'UserNotFound' in code:
                    note = 'TikTok не нашёл доступный эфир. Проверьте ник и запустите LIVE Studio.'
                elif 'Sign' in code or 'RateLimit' in code:
                    note = 'Сервис подключения TikTok недоступен или ограничил запросы.'
                else:
                    note = f'Не удалось подключиться ({code}). Подробности в журнале.'
                self.log(note)
                self.connection_lost(note)
            finally:
                with contextlib.suppress(Exception):
                    await asyncio.wait_for(client.disconnect(close_client=True), 5)
            if self.desired:
                attempt += 1
                await asyncio.sleep(min(30, 3 * (2 ** min(attempt, 3))))

    async def disconnect(self):
        self.desired = False
        self.connection_lost('TikTok отключён')
        if self.connect_task:
            self.connect_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self.connect_task
        self.connect_task = None
        self.client = None

    async def command(self, data):
        action = data.get('action')
        if action == 'settings':
            if self.game.phase not in ('idle', 'finished'):
                raise ValueError('Настройки можно менять между играми')
            if self.desired:
                raise ValueError('Перед изменением настроек отключите TikTok')
            settings = validate_settings(data.get('settings', {}))
            self.config_path.write_text(json.dumps(settings, ensure_ascii=False, indent=2), 'utf-8')
            self.game.settings = settings
            self.log('Настройки сохранены')
        elif action == 'connect':
            if self.game.demo and self.game.phase not in ('idle', 'finished'):
                raise ValueError('Сначала сбросьте демо')
            if not self.desired:
                self.desired = True
                self.connection = 'connecting'
                self.connect_task = asyncio.create_task(self.connect())
        elif action == 'disconnect':
            await self.disconnect()
        elif action in ('start', 'demo'):
            demo = action == 'demo'
            if demo and self.desired:
                raise ValueError('Для демо отключите TikTok')
            if not demo and self.connection != 'online':
                raise ValueError('Сначала подключите активный эфир TikTok')
            self.game.start(demo)
            self.demo_next_join = time.monotonic() + .35
            self.demo_rates.clear()
            self.log('Начался набор • ' + ('ДЕМО' if demo else 'ЭФИР'))
        elif action == 'pause':
            self.game.tick()
            self.game.pause()
        elif action == 'resume':
            if not self.game.demo and self.connection != 'online':
                raise ValueError('Для продолжения восстановите подключение к TikTok')
            self.game.resume()
        elif action == 'reset':
            self.game.reset()
            self.log('Игра сброшена')
        elif action == 'shutdown':
            self.stopping.set()
        else:
            raise ValueError('Неизвестная команда')

    def state(self, admin=False):
        state = self.game.snapshot()
        state['settings'] = self.game.settings
        state['connection'] = self.connection
        if admin:
            state |= dict(connection_note=self.connection_note, events=list(self.events),
                          like_packets=self.like_packets, received_likes=self.received_likes,
                          last_event=self.last_event, last_like=self.last_like, display_url=BASE + '/board')
        return state

    def demo_tick(self):
        g = self.game
        now = time.monotonic()
        if not g.demo:
            return
        if g.phase == 'lobby' and now >= self.demo_next_join:
            names = ['PixelFox', 'neon_kot', 'MaxPlay', 'LunaGG', 'cyber_misha', 'VikaWin',
                     'DarkPanda', 'AlexQuest', 'KiraXP', 'FrostByte', 'turbo_ded', 'Nova']
            i = len(g.players)
            if i < len(names):
                g.join(f'demo-{i}', names[i], avatar=f'/static/avatars/{i}.svg')
                # A few different speeds produce visible eliminations naturally.
                self.demo_rates[f'demo-{i}'] = 1.2 + i * .85
            self.demo_next_join = now + min(.5, g.settings['join_seconds'] / 16)
        if g.phase == 'playing' and now >= self.demo_next_like:
            level = g.level
            for p in list(g.active):
                if g.phase != 'playing' or g.level != level:
                    break
                count = int(self.demo_rates.get(p.id, 4) * random.uniform(.65, 1.4))
                g.like(p.id, max(1, count))
            self.demo_next_like = now + .5

    async def loop(self):
        while not self.stopping.is_set():
            self.game.tick()
            self.demo_tick()
            history = json.dumps(self.game.history, ensure_ascii=False)
            if history != self.last_history:
                (DATA / 'history.json').write_text(history, 'utf-8')
                self.last_history = history
            for ws, admin in list(self.peers):
                try:
                    await asyncio.wait_for(ws.send_json(self.state(admin)), .1)
                except Exception:
                    self.peers.discard((ws, admin))
                    asyncio.create_task(ws.close())
            await asyncio.sleep(.08)  # immediate event handling, display push up to 12.5 Hz


service = Service()


def allowed_origin(request):
    origin = request.headers.get('Origin')
    return not origin or origin == BASE


def admin_auth(request):
    token = request.headers.get('X-LiveGames-Key', '')
    return secrets.compare_digest(token, TOKEN)


@web.middleware
async def guard(request, handler):
    # Reject DNS rebinding and cross-origin commands, including local websites.
    if request.host != f'127.0.0.1:{PORT}':
        raise web.HTTPForbidden(text='Недопустимый адрес')
    if not allowed_origin(request):
        raise web.HTTPForbidden(text='Недопустимый источник')
    response = await handler(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Cache-Control'] = 'no-store'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; connect-src 'self' ws://127.0.0.1:*; frame-ancestors 'self'"
    return response


async def page(request):
    return web.FileResponse(ROOT / 'static' / ('board.html' if request.path == '/board' else 'admin.html'))


async def api(request):
    if not admin_auth(request):
        raise web.HTTPForbidden(text='Ключ администратора недействителен. Перезапустите приложение.')
    try:
        data = await request.json()
        await service.command(data)
        return web.json_response({'ok': True})
    except (ValueError, TypeError, KeyError) as exc:
        return web.json_response({'error': str(exc)}, status=400)


async def socket(request):
    ws = web.WebSocketResponse(heartbeat=10, max_msg_size=4096)
    await ws.prepare(request)
    admin = False
    try:
        first = await asyncio.wait_for(ws.receive_json(), 5)
        admin = secrets.compare_digest(str(first.get('key', '')), TOKEN)
        service.peers.add((ws, admin))
        await ws.send_json(service.state(admin))
        async for message in ws:
            pass  # Commands deliberately use the authenticated HTTP endpoint.
    finally:
        service.peers.discard((ws, admin))
    return ws


async def main():
    app = web.Application(middlewares=[guard], client_max_size=8192)
    app.router.add_get('/', page)
    app.router.add_get('/board', page)
    app.router.add_get('/health', lambda r: web.json_response({'app': 'LiveGames', 'version': '1.0.0'}))
    app.router.add_get('/ws', socket)
    app.router.add_post('/api', api)
    app.router.add_static('/static', ROOT / 'static', show_index=False)
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    try:
        await web.TCPSite(runner, '127.0.0.1', PORT).start()
    except OSError:
        # Reopening the EXE should reopen the existing local app, not spawn a second game.
        import urllib.request
        try:
            with urllib.request.urlopen(BASE + '/health', timeout=2) as response:
                if json.load(response).get('app') != 'LiveGames':
                    raise RuntimeError('Порт занят другой программой')
            webbrowser.open(BASE + '/#' + TOKEN)
        except Exception:
            if sys.platform == 'win32':
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, 'Порт 17891 занят другой программой. Закройте её и попробуйте снова.', 'LiveGames', 16)
        await runner.cleanup()
        return
    if not os.environ.get('LIVEGAMES_NO_BROWSER'):
        webbrowser.open(BASE + '/#' + TOKEN)
    task = asyncio.create_task(service.loop())
    try:
        await service.stopping.wait()
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        await service.disconnect()
        await runner.cleanup()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    except Exception:
        logging.exception('Fatal error')
        if sys.platform == 'win32':
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, 'Не удалось запустить LiveGames. Журнал: ' + str(DATA / 'livegames.log'), 'LiveGames', 16)
